package com.demo.mentordemand.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.mentordemand.model.Skills;

public interface SkillsDao extends JpaRepository<Skills, Integer>{

}
