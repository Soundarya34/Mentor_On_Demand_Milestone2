package com.demo.mentordemand.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.mentordemand.dao.AdminDao;
import com.demo.mentordemand.model.Admin;




@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	 AdminDao adminDao;
	@Override
	public boolean registerAdmin(Admin admin) throws SQLException {
		// TODO Auto-generated method stub
		adminDao.save(admin);
		return true;
	}
	


	@Override
	public Admin loginAdmin(String email, String password) throws SQLException {
		// TODO Auto-generated method stub
		return adminDao.loginAdmin(email,password);
	}
	

}
