package com.demo.mentordemand.controller;

import java.sql.SQLException;

import com.demo.mentordemand.model.Admin;


public interface AdminController {

	public boolean registerAdmin(Admin admin) throws SQLException;
	
	
}
