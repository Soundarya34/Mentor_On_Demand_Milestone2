package com.demo.mentordemand.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.demo.mentordemand.model.Skills;
import com.demo.mentordemand.model.Admin;
import com.demo.mentordemand.model.Mentor;
import com.demo.mentordemand.service.MentorService;
import com.demo.mentordemand.service.SkillsService;

@Controller
public class MentorControllerImpl implements MentorController{

	@Autowired
	MentorService mentorService;
	
	@Autowired
	SkillsService skillsService;

	@Override
	public boolean registerMentor(Mentor mentor) throws SQLException {
		// TODO Auto-generated method stub
		return mentorService.registerMentor(mentor);
	}
	

	@RequestMapping(path = "/registerMentorPage", method = RequestMethod.GET)
	public ModelAndView registerAdminPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		List<Skills> skillsList;
		skillsList=skillsService.getSkillsList();
		mv.setViewName("registerMentor");
		model.addAttribute("registerMentor", new Mentor());
		model.addAttribute("skillsList", skillsList);
		model.addAttribute("searchMentor", new Mentor());
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}

	@RequestMapping(value = "/registerMentor", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("registerMentor") Mentor registerMentor, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			List<Skills> skillsList;
			skillsList=skillsService.getSkillsList();
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			map.addAttribute("registerMentor", registerMentor);
			map.addAttribute("skillsList", skillsList);
			mav = new ModelAndView("registerMentor");
			return mav;
		}

		else {
			map.addAttribute("registerMentor", registerMentor);
			mentorService.registerMentor(registerMentor);
			mav = new ModelAndView("home");
			// if (registerUser.getUsertype().equalsIgnoreCase("Admin")) {
			// map.addAttribute("adminLogin", new User());
			// mav = new ModelAndView("adminLogin");
			// } else {
			// map.addAttribute("userLogin", new User());
			// mav = new ModelAndView("userLogin");
			// }

			return mav;
		}

	}

	@RequestMapping(path = "/mentorLoginPage", method = RequestMethod.GET)
	public ModelAndView loginMentorPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("mentorLogin");
		model.addAttribute("mentorLogin", new Mentor());
		return mv;
	}

	@RequestMapping(value = "/mentorLogin", method = RequestMethod.POST)
	public ModelAndView adminLogin(@ModelAttribute("mentorLogin") Mentor mentorLogin, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("mentorLogin",mentorLogin);
		Mentor check = mentorService.loginMentor(mentorLogin.getEmail(), mentorLogin.getPassword());
		if (check != null) {
			mav = new ModelAndView("home");
		}

		else {
			map.addAttribute("mentorLogin", mentorLogin);
			mav = new ModelAndView("mentorLogin");
		}

		return mav;
	}
	

}
