package com.demo.mentordemand.dao;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.mentordemand.model.User;



public interface UserDao extends JpaRepository<User, Integer> {

	@Query("Select u From User u where u.email=:email and u.password=:password")
	User loginUser(@Param("email") String email, @Param("password") String password);

	@Query("Select u.username from User u where u.email =:email")
	public String findByUsername(@Param("email")String email);

	@Query("Select u.userId from User u where u.username =:username")
	public int findByUserId(@Param("username")String username);

}
