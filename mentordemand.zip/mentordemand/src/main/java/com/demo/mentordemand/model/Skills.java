package com.demo.mentordemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "skills")
public class Skills {

	@Column(name = "skill_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int skillId;
	@Column(name = "skill_name")
	private String skillName;
	@Column(name = "base_amount")
	private double baseAmount;
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	public double getBaseAmount() {
		return baseAmount;
	}
	public void setBaseAmount(double baseAmount) {
		this.baseAmount = baseAmount;
	}
	public Skills(int skillId, String skillName, double baseAmount) {
		super();
		this.skillId = skillId;
		this.skillName = skillName;
		this.baseAmount = baseAmount;
	}
	public Skills() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Skills [skillId=" + skillId + ", skillName=" + skillName + ", baseAmount=" + baseAmount + "]";
	}
	
	
	
	
	
}
