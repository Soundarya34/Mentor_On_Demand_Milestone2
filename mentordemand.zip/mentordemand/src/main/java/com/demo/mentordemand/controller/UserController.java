package com.demo.mentordemand.controller;

import java.sql.SQLException;

import com.demo.mentordemand.model.User;



public interface UserController {

	
	public boolean registerUser(User user) throws SQLException;
	
	
}
