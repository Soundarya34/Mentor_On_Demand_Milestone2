package com.demo.mentordemand.controller;

public interface HomeController {

}
