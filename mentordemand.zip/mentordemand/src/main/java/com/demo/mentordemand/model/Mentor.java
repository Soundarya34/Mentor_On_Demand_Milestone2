package com.demo.mentordemand.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "mentor")
public class Mentor {

	public Mentor() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mentorId")
	private int mentorId;
	@Column(name = "mentor_name")
	private String mentorName;

	@Column(name = "email")
	private String email;
	@Column(name = "password")
	private String password;
	@Column(name = "address")
	private String address;
	@Column(name = "linkedin_url")
	private String linkedinUrl;
	@Column(name = "slot_time")
	private String slotTime;
	@Column(name = "technology")
	private String technology;
	@Column(name = "experience")
	private String experience;
	@Column(name = "mobile_number")
	private long mobileNumber;
	@Column(name = "reg_date_time")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date regDateTime;
	@Column(name = "status")
	private String status;
	
	
	
	
	public int getMentorId() {
		return mentorId;
	}
	public void setMentorId(int mentorId) {
		this.mentorId = mentorId;
	}
	public String getMentorName() {
		return mentorName;
	}
	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLinkedinUrl() {
		return linkedinUrl;
	}
	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}
	public String getSlotTime() {
		return slotTime;
	}
	public void setSlotTime(String slotTime) {
		this.slotTime = slotTime;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	
	public Date getRegDateTime() {
		return regDateTime;
	}
	public void setRegDateTime(Date regDateTime) {
		this.regDateTime = regDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Mentor(int mentorId, String mentorName, String email, String password, String address, String linkedinUrl,
			String slotTime, String technology, String experience, long mobileNumber, Date regDateTime,
			String status) {
		super();
		this.mentorId = mentorId;
		this.mentorName = mentorName;
		this.email = email;
		this.password = password;
		this.address = address;
		this.linkedinUrl = linkedinUrl;
		this.slotTime = slotTime;
		this.technology = technology;
		this.experience = experience;
		this.mobileNumber = mobileNumber;
		this.regDateTime = regDateTime;
		this.status = status;
	}
	@Override
	public String toString() {
		return "Mentor [mentorId=" + mentorId + ", mentorName=" + mentorName + ", email=" + email + ", password="
				+ password + ", address=" + address + ", linkedinUrl=" + linkedinUrl + ", slotTime=" + slotTime
				+ ", technology=" + technology + ", experience=" + experience + ", mobileNumber=" + mobileNumber
				+ ", regDateTime=" + regDateTime + ", status=" + status + "]";
	}
	
	
	
	

}
