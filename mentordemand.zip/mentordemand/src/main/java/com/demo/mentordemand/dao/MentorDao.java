package com.demo.mentordemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.mentordemand.model.Mentor;

public interface MentorDao  extends JpaRepository<Mentor, Integer> {

	@Query("Select m From Mentor m where m.email=:email and m.password=:password")
	Mentor loginMentor(@Param("email") String email,@Param("password") String password);

	@Query("Select m From Mentor m where m.technology=:technology")
	List<Mentor> findByTechnology(@Param("technology")String technology);

}
