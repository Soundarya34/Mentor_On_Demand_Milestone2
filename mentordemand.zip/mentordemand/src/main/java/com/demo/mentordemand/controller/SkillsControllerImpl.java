package com.demo.mentordemand.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.mentordemand.model.Admin;
import com.demo.mentordemand.model.Mentor;
import com.demo.mentordemand.model.Skills;
import com.demo.mentordemand.service.SkillsService;


@Controller
public class SkillsControllerImpl implements SkillsController{

	

	@Autowired
	SkillsService skillsService;

	@Override
	public boolean registerSkill(Skills skills) throws SQLException {
		// TODO Auto-generated method stub
		return skillsService.registerSkill(skills);
	}
	
	@RequestMapping(path = "/addSkillsPage", method = RequestMethod.GET)
	public ModelAndView addSkills(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addSkills");
		model.addAttribute("addSkills", new Skills());
		model.addAttribute("searchMentor", new Mentor());
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}
	
	@RequestMapping(value = "/addSkills", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("addSkills") Skills skills, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			map.addAttribute("addSkills", skills);
			mav = new ModelAndView("addSkills");
			mav.addObject("skillsList", skillsService.getSkillsList());
			return mav;
		}

		else {
			map.addAttribute("addSkills",skills);
			skillsService.registerSkill(skills);
			mav = new ModelAndView("skillsList");
			mav.addObject("skillsList", skillsService.getSkillsList());
			return mav;
		}

	}
	
	@RequestMapping(path = "/skillsList")
	public ModelAndView getSkillsList() throws SQLException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("skillsList");
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}
	
	

}
