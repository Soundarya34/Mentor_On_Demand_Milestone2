package com.demo.mentordemand.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.mentordemand.dao.SkillsDao;
import com.demo.mentordemand.model.Skills;


@Service
public class SkillsServiceImpl implements SkillsService{
	
	
	@Autowired
	 SkillsDao skillsDao;
	@Override
	public boolean registerSkill(Skills skills) throws SQLException {
		// TODO Auto-generated method stub
		skillsDao.save(skills);
		return true;
	}
	
	
	@Override
	public List<Skills> getSkillsList() throws SQLException {
		// TODO Auto-generated method stub
		return skillsDao.findAll();
	}

}
