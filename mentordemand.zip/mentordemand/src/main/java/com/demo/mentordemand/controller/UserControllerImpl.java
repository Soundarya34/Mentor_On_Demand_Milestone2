package com.demo.mentordemand.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.mentordemand.dao.RequestTrainingDao;
import com.demo.mentordemand.dao.UserDao;
import com.demo.mentordemand.model.Admin;
import com.demo.mentordemand.model.Mentor;
import com.demo.mentordemand.model.RequestTraining;
import com.demo.mentordemand.model.User;
import com.demo.mentordemand.service.SkillsService;
import com.demo.mentordemand.service.UserService;

@Controller
public class UserControllerImpl implements UserController{

	@Autowired
    UserService userService;
	
	@Autowired
	SkillsService skillsService;
	
	@Autowired
	UserDao userDao;
	

	
	
	@Autowired
	RequestTrainingDao reqTrainingDao;
	
	
	@Override
	public boolean registerUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return userService.registerUser(user);
	}
	
	
	
	
	
	
	@RequestMapping(path = "/registerUserPage", method = RequestMethod.GET)
	public ModelAndView registerUserPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerUser");
		model.addAttribute("registerUser", new User());
		model.addAttribute("searchMentor", new Mentor());
		mv.addObject("skillsList", skillsService.getSkillsList());
		return mv;
	}
	
	
	
	
	
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public ModelAndView registerUser( @ModelAttribute("registerUser") User registerUser, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			map.addAttribute("registerUser", registerUser);
			mav = new ModelAndView("registerUser");
			return mav;
		}

		else {
			map.addAttribute("registerUser", registerUser);
			userService.registerUser(registerUser);
			mav=new ModelAndView("userLogin");
			map.addAttribute("userLogin", new User());
//			if (registerUser.getUsertype().equalsIgnoreCase("Admin")) {
//				map.addAttribute("adminLogin", new User());
//				mav = new ModelAndView("adminLogin");
//			} else {
//				map.addAttribute("userLogin", new User());
//				mav = new ModelAndView("userLogin");
//			}

			return mav;
		}

	}

	
	
	@RequestMapping(path = "/userLoginPage", method = RequestMethod.GET)
	public ModelAndView loginUserPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("userLogin");
		model.addAttribute("userLogin", new User());
		return mv;
	}

	@RequestMapping(value = "/userLogin", method = RequestMethod.POST)
	public ModelAndView adminLogin(@ModelAttribute("userLogin")User userLogin, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map,Model model) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("userLogin", userLogin);
		User check = userService.loginUser(userLogin.getEmail(), userLogin.getPassword());
		session=request.getSession();
		String username=userDao.findByUsername(userLogin.getEmail());
		session.setAttribute("userName",username);
		if (check != null) {
			
			mav = new ModelAndView("userLandingPage");
			model.addAttribute("searchMentor", new Mentor());
			mav.addObject("skillsList", skillsService.getSkillsList());
		}

		else {
			map.addAttribute("userLogin", userLogin);
			mav = new ModelAndView("userLogin");
		}

		return mav;
	}
	
	@RequestMapping(value = "/requestTrainingPage", method = RequestMethod.GET)
	public ModelAndView requestTrainingPage(@RequestParam("mentorId")int mentorId,@RequestParam("mentorName")String mentorName,@RequestParam("userName")String userName,@RequestParam("technology")String technology , Model model) throws Exception {
	
		int userId=userDao.findByUserId(userName);
		RequestTraining reqTraining=new RequestTraining();
		reqTraining.setMentorId(mentorId);
		reqTraining.setMentorName(mentorName);
		reqTraining.setTechnology(technology);
		reqTraining.setUserName(userName);
	    reqTraining.setUserId(userId);
		reqTrainingDao.save(reqTraining);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
			return mv;
	}
	





	

}
