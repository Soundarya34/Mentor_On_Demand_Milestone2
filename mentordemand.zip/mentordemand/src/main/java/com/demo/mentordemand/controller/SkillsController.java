package com.demo.mentordemand.controller;

import java.sql.SQLException;

import org.springframework.web.servlet.ModelAndView;

import com.demo.mentordemand.model.Skills;

public interface SkillsController {

	public boolean registerSkill(Skills skills) throws SQLException;
	
	public ModelAndView getSkillsList() throws Exception;
}
