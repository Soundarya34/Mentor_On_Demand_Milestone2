package com.demo.mentordemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin {

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Column(name = "adminId")
	@Id@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int adminId;
	@Column(name = "admin_name")
	private String adminName;
	@Column(name = "gender")
	private String gender;
	@Column(name = "email")
	private String email;
	@Column(name = "password")
	private String password;
	@Column(name = "address")
	private String address;
	@Column(name = "mobile_number")
	private long mobileNumber;



	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", gender=" + gender + ", email=" + email
				+ ", password=" + password + ", address=" + address + ", mobileNumber=" + mobileNumber + "]";
	}
	
	

}
