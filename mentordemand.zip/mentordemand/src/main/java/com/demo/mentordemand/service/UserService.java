package com.demo.mentordemand.service;

import java.sql.SQLException;

import org.springframework.stereotype.Service;

import com.demo.mentordemand.model.User;



public interface UserService {

	public boolean registerUser(User user) throws SQLException;

	public User loginUser(String email, String password) throws SQLException;
 
}
