package com.demo.mentordemand.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.mentordemand.model.Mentor;

public interface MentorService {

	public boolean  registerMentor(Mentor mentor)  throws SQLException;

	public Mentor loginMentor(String email, String password)  throws SQLException;

	public List<Mentor> findByTechnology(String mentorSkill);

}
